export default {
  verbose: true,
  testTimeout: 20000,
};
