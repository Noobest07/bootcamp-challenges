import User from './user.model.js';
import Fav from './fav.model.js';

export { User, Fav };
