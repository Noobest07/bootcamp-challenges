import * as userCtrl from './user.controller.js';
import * as favCtrl from './fav.controller.js';

export { userCtrl, favCtrl };
