import userRouter from './user.router.js';
import favRouter from './fav.router.js';

export { userRouter, favRouter };
